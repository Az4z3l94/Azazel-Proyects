<?php include 'prip/initial.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/styles.css">

</head>

<body>
    <div class="contenedor">
        <div style="max-width: 300px;">
            <form action="functions/registro.php" method="post">
                <div class="imgcontainer">
                    <img src="assets/img/avatar.png" style="max-width: 80px;" alt="Avatar" class="avatar">
                </div>

                <div class="container">
                    <label for="nombre"><b>Nombre</b></label>
                    <input type="text" placeholder="Ingresa tu nombre" name="nombre" required>

                    <label for="email"><b>Email</b></label>
                    <input type="text" placeholder="Ingresa tu email" name="email" required>

                    <label for="password"><b>Contraseña</b></label>
                    <input type="password" placeholder="Ingresa tu contraseña" name="password" required>

                    <button type="submit">Registrar</button>

                </div>

                <div class="container" style="background-color:#f1f1f1">
                    <span class="psw">Olvidaste tu <a href="recuperar.php">Contraseña?</a></span>
                </div>
            </form>
        </div>
    </div>

</body>


</html>