<?php include 'prip/initial.php';

if (isset($_SESSION['nombrelogeado'])) {
    header('Location: perfil.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/styles.css">

</head>

<body>
    <div class="contenedor">
        <div style="max-width: 300px;">
            <form action="functions/login.php" method="post">
                <div class="imgcontainer">
                    <img src="assets/img/avatar.png" style="max-width: 80px;" alt="Avatar" class="avatar">
                </div>

                <div class="container">
                    <label for="email"><b>Email</b></label>
                    <input type="text" placeholder="Ingresa tu email" name="email" value="<?php echo htmlspecialchars($emailRecuerdo); ?>" required>

                    <label for="password"><b>Contraseña</b></label>
                    <input type="password" placeholder="Ingresa tu contraseña" name="password" value="<?php echo htmlspecialchars($contraRecuerdo); ?>" required>

                    <button type="submit">Ingresar</button>
                    <label>
                        <input type="checkbox" <?php if (isset($_COOKIE['email_recuerdo'])) echo 'checked'; ?> name="remember"> Recordar datos
                    </label>
                </div>

                <div class="container" style="background-color:#f1f1f1">
                    <span class="psw">Olvidaste tu <a href="recuperar.php">Contraseña?</a></span>
                </div>
            </form>
        </div>
    </div>

</body>


</html>