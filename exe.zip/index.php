<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="contenedor">
        <div style="max-width: 300px;">

            <a href="registro.php">CREAR CUENTA</a>
            <BR>
            <BR>
            <BR>
            <a href="login.php">INICIAR SESION</a>

        </div>
    </div>

</body>


</html>