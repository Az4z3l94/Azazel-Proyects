<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/styles.css">

</head>

<body>
    <div class="contenedor">
        <div style="max-width: 300px;">
            <form action="functions/recuperarpass.php" method="post">
                <div class="imgcontainer">
                    <img src="assets/img/avatar.png" style="max-width: 80px;" alt="Avatar" class="avatar">
                </div>

                <div class="container">
                    <label for="uname"><b>Email</b></label>
                    <input type="text" placeholder="Ingresa tu email" name="uname" required>



                    <button type="submit">Recuperar</button>

                </div>


            </form>
        </div>
    </div>

</body>


</html>