<?php include 'prip/initial.php';
?>



hola <?php echo $nombre1; ?>
<br>

tu correo es <?php echo $email1; ?>

<br>

<a href="logout.php">cerrar sesion </a>