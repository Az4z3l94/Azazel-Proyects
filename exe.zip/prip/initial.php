<?php
session_start();
if (isset($_COOKIE['email_recuerdo'])) {
    $emailRecuerdo = $_COOKIE['email_recuerdo'];
    $contraRecuerdo = $_COOKIE['contra_recuerdo'];
} else {
    $emailRecuerdo = "";
    $contraRecuerdo = "";
}
include 'db.php';

if (isset($_SESSION['nombrelogeado'])) {
    $login1 =  $_SESSION['emaillogeado'];
    $datospersonalogeada = "SELECT email, nombre FROM cuentas WHERE email = '$login1'";
    $datospersonalogeadaa = mysqli_query($con, $datospersonalogeada);
    $row1 = mysqli_fetch_assoc($datospersonalogeadaa);
    $nombre1 = $row1['nombre'];
    $email1 = $row1['email'];
}
