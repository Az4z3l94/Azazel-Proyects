<?php
$servername = "127.0.0.1:3306";
$username = "exequiel";
$password = "exequiel";
$dbname = "exequiel";

$con = mysqli_connect($servername, $username, $password, $dbname);
if (!$con) {
    die("La conexion fallo" . mysqli_connect_error());
}
