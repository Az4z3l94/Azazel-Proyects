<?php
include '../prip/db.php';
include '../prip/initial.php';

$nombreregistro = $_POST['nombre'];
$emailregistro = $_POST['email'];
$contraseñaregistro = $_POST['password'];

$existecuenta = "SELECT email FROM cuentas WHERE email = '$emailregistro'";
$existecuentaa = mysqli_query($con, $existecuenta);

if ($existecuentaa && mysqli_num_rows($existecuentaa) == 1) {
    echo '<div>Este correo ya esta registrado.</div>';
    echo '<script>function redireccionar(){window.location.href = "../registro.php";} setTimeout("redireccionar()", 4000);</script>';
} else {
    $crearcuenta = "INSERT INTO cuentas (nombre, email, contraseña) VALUES ('$nombreregistro', '$emailregistro', '$contraseñaregistro')";
    $ejecutarcrearcuenta = mysqli_query($con, $crearcuenta);

    echo '<div>Cuenta registrada con exito.</div>';
    echo '<script>function redireccionar(){window.location.href = "../login.php";} setTimeout("redireccionar()", 4000);</script>';
}





// if ($existecuentaa && mysqli_num_rows($existecuentaa) == 1) {
//     $estabiencontraseña = "SELECT email, nombre, contraseña FROM cuentas WHERE email = '$emaillogeo' AND contraseña = '$contraseñalogeo'";
//     $estabiencontraseñaa = mysqli_query($con, $estabiencontraseña);
//     if ($estabiencontraseñaa && mysqli_num_rows($estabiencontraseñaa) == 1) {
//         $row = mysqli_fetch_assoc($estabiencontraseñaa);
//         $nombre = $row['nombre'];
//         $email = $row['email'];
//         $_SESSION['nombrelogeado'] = $nombre;
//         $_SESSION['emaillogeado'] = $email;
//         if (isset($_POST['remember'])) {
//             $cookieExpiration = time() + 7 * 24 * 60 * 60;
//             setcookie('email_recuerdo', $emaillogeo, $cookieExpiration, '/');
//             setcookie('contra_recuerdo', $contraseñalogeo, $cookieExpiration, '/');
//         }
//         echo '<div>Inicio de sesion exitoso. seras redirigido a tu perfil.</div>';
//         echo '<script>function redireccionar(){window.location.href = "../perfil.php";} setTimeout("redireccionar()", 3000);</script>';
//     } else {
//         echo '<div>Contraseña Incorrecta.</div>';
//         echo '<script>function redireccionar(){window.location.href = "../login.php";} setTimeout("redireccionar()", 4000);</script>';
//     }
// } else {
//     echo '<div>Cuenta no registrada.</div>';
//     echo '<script>function redireccionar(){window.location.href = "../login.php";} setTimeout("redireccionar()", 4000);</script>';
// }
