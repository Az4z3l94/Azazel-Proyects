<?php
include '../prip/db.php';
include '../prip/initial.php';

$emaillogeo = $_POST['email'];
$contraseñalogeo = $_POST['password'];


$existecorreo = "SELECT email, nombre, contraseña FROM cuentas WHERE email = '$emaillogeo'";

$existecorreoo = mysqli_query($con, $existecorreo);

if ($existecorreoo && mysqli_num_rows($existecorreoo) == 1) {

    $estabiencontraseña = "SELECT email, nombre, contraseña FROM cuentas WHERE email = '$emaillogeo' AND contraseña = '$contraseñalogeo'";

    $estabiencontraseñaa = mysqli_query($con, $estabiencontraseña);

    if ($estabiencontraseñaa && mysqli_num_rows($estabiencontraseñaa) == 1) {
        $row = mysqli_fetch_assoc($estabiencontraseñaa);
        $nombre = $row['nombre'];
        $email = $row['email'];

        $_SESSION['nombrelogeado'] = $nombre;
        $_SESSION['emaillogeado'] = $email;
        if (isset($_POST['remember'])) {
            $cookieExpiration = time() + 7 * 24 * 60 * 60;
            setcookie('email_recuerdo', $emaillogeo, $cookieExpiration, '/');
            setcookie('contra_recuerdo', $contraseñalogeo, $cookieExpiration, '/');
        }
        echo '<div>Inicio de sesion exitoso. seras redirigido a tu perfil.</div>';
        echo '<script>function redireccionar(){window.location.href = "../perfil.php";} setTimeout("redireccionar()", 3000);</script>';
    } else {
        echo '<div>Contraseña Incorrecta.</div>';
        echo '<script>function redireccionar(){window.location.href = "../login.php";} setTimeout("redireccionar()", 4000);</script>';
    }
} else {
    echo '<div>Cuenta no registrada.</div>';
    echo '<script>function redireccionar(){window.location.href = "../login.php";} setTimeout("redireccionar()", 4000);</script>';
}











// $sql = "SELECT email, nombre, contraseña FROM cuentas WHERE email = '$emaillogeo' AND contraseña = '$contraseñalogeo'";

// $resultado = mysqli_query($con, $sql);

// if ($resultado && mysqli_num_rows($resultado) == 1) {
//     $row = mysqli_fetch_assoc($resultado);
//     $nombre = $row['nombre'];
//     $email = $row['email'];

//     $_SESSION['nombrelogeado'] = $nombre;
//     $_SESSION['emaillogeado'] = $email;
//     if (isset($_POST['remember'])) {
//         $cookieExpiration = time() + 7 * 24 * 60 * 60;
//         setcookie('email_recuerdo', $emaillogeo, $cookieExpiration, '/');
//         setcookie('contra_recuerdo', $contraseñalogeo, $cookieExpiration, '/');
//     }
//     echo '<div>Inicio de sesion exitoso. seras redirigido a tu perfil.</div>';
//     echo '<script>function redireccionar(){window.location.href = "../perfil.php";} setTimeout("redireccionar()", 3000);</script>';
// }
